/**
 * Elmentti egy kocsiszín adatait az adatábzisba
 */

module.exports = function (objectreposity) {
    return function (req, res, next) {
        return next();
    };
};