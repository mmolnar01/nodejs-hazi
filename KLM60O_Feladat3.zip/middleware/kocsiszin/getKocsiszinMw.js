/**
 * Lekérdezi egy kocsiszín adatatait az adatbázisból
 */

module.exports = function (objectreposity) {
    return function (req, res, next) {
        return next();
    };
};